# Smarter Flare animation using Flutter - Final

This is the final result for the tutorial. [Smarter Flare animations with Flutter](https://medium.com/filledstacks/better-animations-in-flutter-using-flare-an-experiment-ddcb35ab0650)