# Final

This is the completed tutorial code for building the Tik Tok UI. You can see both [Part1](https://medium.com/filledstacks/breaking-down-tiktoks-ui-using-flutter-8489fe4ad944) and [Part2](https://medium.com/filledstacks/building-tiktoks-ui-in-flutter-part-2-build-the-small-parts-42fb2089d605) on the [FilledStacks Publication](https://medium.com/filledstacks)