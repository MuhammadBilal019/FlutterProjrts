class AppInfo {
  String get welcomeMessage => 'Hello from FilledStacks';
}